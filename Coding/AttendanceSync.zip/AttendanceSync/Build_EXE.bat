@echo off
setlocal
cd /d "%~dp0"
title Build Attendance Sync EXE

set "PY="
py -3 --version >nul 2>nul && set "PY=py -3"
if not defined PY python --version >nul 2>nul && set "PY=python"

if not defined PY (
  echo Python not found. Installing it now...
  winget install -e --id Python.Python.3.13 --scope user --silent --accept-package-agreements --accept-source-agreements
)
if not defined PY if exist "%LocalAppData%\Programs\Python\Python313\python.exe" set PY="%LocalAppData%\Programs\Python\Python313\python.exe"

if not defined PY (
  echo Could not install Python automatically. Install it from https://www.python.org/downloads/ and run this again.
  pause
  exit /b 1
)

%PY% -m pip install --upgrade pip pyinstaller selenium openpyxl xlwings
%PY% -m PyInstaller --onefile --windowed --hidden-import xlwings --name AttendanceSync attendance_sync_app.py

echo.
echo Finished. Your app is: dist\AttendanceSync.exe
echo Give that single file to the teachers.
pause
