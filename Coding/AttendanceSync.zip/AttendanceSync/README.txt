BEFORE HANDING OUT: open attendance_sync_app.py in Notepad and fill in the
lines marked  <<< FILL IN  (login, XPaths, Excel columns). Save it.

OPTION 1 (simplest): give teachers this whole folder.
  They double-click Setup_and_Run.bat. First time it installs Python and
  the libraries (needs internet); after that it just opens the app.

OPTION 2 (single file): double-click Build_EXE.bat once on any Windows PC.
  It creates dist\AttendanceSync.exe - give teachers only that file.
  (Fill in the script BEFORE building.)

Teachers also need: Windows, desktop Excel, and Google Chrome.
