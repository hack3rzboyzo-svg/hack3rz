@echo off
setlocal
cd /d "%~dp0"
title Attendance Sync

set "PY="
py -3 --version >nul 2>nul && set "PY=py -3"
if not defined PY python --version >nul 2>nul && set "PY=python"

if not defined PY (
  echo Python not found. Installing it now - this only happens once...
  winget install -e --id Python.Python.3.13 --scope user --silent --accept-package-agreements --accept-source-agreements
)
if not defined PY if exist "%LocalAppData%\Programs\Python\Python313\python.exe" set PY="%LocalAppData%\Programs\Python\Python313\python.exe"

if not defined PY (
  echo.
  echo Could not install Python automatically.
  echo Please install it from https://www.python.org/downloads/ and tick "Add python.exe to PATH",
  echo then double-click this file again.
  pause
  exit /b 1
)

%PY% -c "import selenium, openpyxl, xlwings" >nul 2>nul
if errorlevel 1 (
  echo Installing required libraries - one time only...
  %PY% -m pip install --upgrade pip selenium openpyxl xlwings
  if errorlevel 1 (
    echo Install failed. Check your internet connection and try again.
    pause
    exit /b 1
  )
)

%PY% attendance_sync_app.py
