"""
Attendance Sync - simple window for teachers.
Pick a source, click Sync. Marks "/" (present) or "O" (absent) on the
ACTIVE sheet of the open Excel workbook, in the column the teacher has
selected, for students already on that sheet.

Needs: Google Chrome installed (for the Website option).
"""

import csv
import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# =====================================================================
# >>>>>>>>>>>>>>>>>>>>>>>>  FILL THESE IN  <<<<<<<<<<<<<<<<<<<<<<<<<<<<
# =====================================================================

# --- Login details (plain text) ---
USERNAME = ""   # <<< FILL IN: your username
PASSWORD = ""   # <<< FILL IN: your password

# --- Website address ---
SITE_URL       = ""   # <<< FILL IN: the login page address
ATTENDANCE_URL = ""   # <<< OPTIONAL: attendance page address (leave "" if login lands on it)

# --- Login XPaths (right-click the element in Chrome > Inspect > right-click the
#     highlighted code > Copy > Copy XPath) ---
USERNAME_XPATH     = ""   # <<< FILL IN: username box
PASSWORD_XPATH     = ""   # <<< FILL IN: password box
LOGIN_BUTTON_XPATH = ""   # <<< FILL IN: login button

# --- Attendance XPaths ---
ROW_XPATH    = ""   # <<< FILL IN: ONE student's row, written so it matches every student row, e.g. //table//tr[td]
NAME_XPATH   = ""   # <<< FILL IN: name inside a row, starts with a dot, e.g. .//td[1]
STATUS_XPATH = ""   # <<< FILL IN: present/absent inside a row, e.g. .//td[2]

# --- What the site writes for "present" (anything else counts as absent) ---
PRESENT_WORDS = ["present", "p", "yes", "attended", "/"]   # <<< CHECK these match your site

# --- Teacher's Excel sheet ---
NAME_COLUMN    = "A"   # <<< FILL IN: column with student names in Excel
FIRST_DATA_ROW = 2     # <<< FILL IN: first student row in Excel

# --- For the "Excel file" and "App export" options: which column (0 = first) has what ---
FILE_NAME_COL   = 0
FILE_STATUS_COL = 1

# =====================================================================

PRESENT_MARK = "/"
ABSENT_MARK = "O"


def norm(name):
    return " ".join(str(name).lower().split())


def is_present(value):
    return str(value).strip().lower() in [w.lower() for w in PRESENT_WORDS]


# ---------------------------- SOURCES --------------------------------

def from_website():
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.common.exceptions import NoSuchElementException

    opts = webdriver.ChromeOptions()
    opts.add_argument("--headless=new")
    driver = webdriver.Chrome(options=opts)
    try:
        wait = WebDriverWait(driver, 20)
        driver.get(SITE_URL)
        wait.until(EC.presence_of_element_located((By.XPATH, USERNAME_XPATH))).send_keys(USERNAME)
        driver.find_element(By.XPATH, PASSWORD_XPATH).send_keys(PASSWORD)
        old_url = driver.current_url
        driver.find_element(By.XPATH, LOGIN_BUTTON_XPATH).click()
        wait.until(lambda d: d.current_url != old_url or not d.find_elements(By.XPATH, PASSWORD_XPATH))
        if ATTENDANCE_URL:
            driver.get(ATTENDANCE_URL)
        rows = wait.until(EC.presence_of_all_elements_located((By.XPATH, ROW_XPATH)))
        out = {}
        for row in rows:
            try:
                name = row.find_element(By.XPATH, NAME_XPATH).text
                status = row.find_element(By.XPATH, STATUS_XPATH).text
            except NoSuchElementException:
                continue
            if name.strip():
                out[norm(name)] = is_present(status)
        return out
    finally:
        driver.quit()


def rows_to_dict(rows):
    out = {}
    for row in rows:
        if len(row) > max(FILE_NAME_COL, FILE_STATUS_COL) and str(row[FILE_NAME_COL]).strip():
            out[norm(row[FILE_NAME_COL])] = is_present(row[FILE_STATUS_COL])
    return out


def from_excel_file(path):
    from openpyxl import load_workbook
    ws = load_workbook(path, read_only=True, data_only=True).active
    return rows_to_dict([[("" if v is None else v) for v in r] for r in ws.iter_rows(values_only=True)])


def from_app_export(path):
    if path.lower().endswith((".xlsx", ".xlsm")):
        return from_excel_file(path)
    with open(path, newline="", encoding="utf-8-sig") as f:
        return rows_to_dict(list(csv.reader(f)))


# ------------------------ WRITE TO ACTIVE SHEET -----------------------

def write_to_active_sheet(attendance):
    import xlwings as xw
    try:
        app = xw.apps.active
        ws = app.books.active.sheets.active
        target_col = app.selection.column
    except Exception:
        raise RuntimeError("Couldn't find an open Excel workbook. Open it first.")

    name_col = ws.range(f"{NAME_COLUMN}1").column
    if target_col == name_col:
        raise RuntimeError("Click a cell in the column you want marked (e.g. today's date) first.")

    last = ws.used_range.last_cell.row
    matched, missing, seen = 0, [], set()
    for r in range(int(FIRST_DATA_ROW), last + 1):
        name = ws.range((r, name_col)).value
        if not name:
            continue
        key = norm(name)
        if key in attendance:
            ws.range((r, target_col)).value = PRESENT_MARK if attendance[key] else ABSENT_MARK
            matched += 1
            seen.add(key)
        else:
            missing.append(str(name))
    extra = [k for k in attendance if k not in seen]
    return ws.name, matched, missing, extra


# ------------------------------- GUI ----------------------------------

def main():
    root = tk.Tk()
    root.title("Attendance Sync")
    root.geometry("420x380")
    frm = ttk.Frame(root, padding=14)
    frm.pack(fill="both", expand=True)

    ttk.Label(frm, text="1. In Excel, click a cell in the column to fill.").pack(anchor="w")
    ttk.Label(frm, text="2. Choose where the attendance comes from:").pack(anchor="w", pady=(8, 2))
    source = ttk.Combobox(frm, state="readonly", values=["Website", "Excel file", "App export"])
    source.current(0)
    source.pack(fill="x")

    log = tk.Text(frm, height=10, state="disabled", wrap="word")

    def say(msg):
        log.config(state="normal")
        log.insert("end", msg + "\n")
        log.config(state="disabled")
        log.see("end")
        root.update_idletasks()

    def sync():
        log.config(state="normal")
        log.delete("1.0", "end")
        log.config(state="disabled")
        try:
            choice = source.get()
            if choice == "Website":
                say("Logging in and fetching attendance...")
                data = from_website()
            else:
                path = filedialog.askopenfilename(
                    title="Choose the " + ("Excel file" if choice == "Excel file" else "app export"),
                    filetypes=[("Excel / CSV", "*.xlsx *.xlsm *.csv"), ("All files", "*.*")])
                if not path:
                    return
                data = from_excel_file(path) if choice == "Excel file" else from_app_export(path)
            say(f"Got {len(data)} students.")
            sheet, matched, missing, extra = write_to_active_sheet(data)
            say(f"Done! Updated {matched} students on sheet '{sheet}'.")
            if missing:
                say("Not found in the source: " + ", ".join(missing))
            if extra:
                say("Not on your sheet (skipped): " + ", ".join(extra))
        except Exception as e:
            messagebox.showerror("Attendance Sync", str(e))

    ttk.Button(frm, text="Sync now", command=sync).pack(fill="x", pady=8)
    log.pack(fill="both", expand=True)
    root.mainloop()


if __name__ == "__main__":
    main()
